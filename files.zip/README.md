# 🌸 SwapStyle Web — Deploy Guide

## Rodar local (teste)

```bash
cd swapstyle_web
pip install flask
python app.py
```
Acesse: http://localhost:5000

---

## Deploy gratuito no Render.com

1. Crie conta em https://render.com (grátis)
2. Clique em **New → Web Service**
3. Conecte seu GitHub e faça upload desta pasta
4. Configure:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app --bind 0.0.0.0:$PORT`
   - **Environment:** Python 3
5. Adicione variável de ambiente:
   - `SECRET_KEY` = qualquer string longa e aleatória
6. Clique **Deploy** — em 2 minutos seu link estará ativo!

## Deploy gratuito no Railway.app

1. Crie conta em https://railway.app
2. New Project → Deploy from GitHub
3. Selecione a pasta do projeto
4. Railway detecta automaticamente o Procfile
5. Adicione variável: `SECRET_KEY=sua-chave-secreta`
6. Seu link aparece no dashboard!

---

## Estrutura dos arquivos

```
swapstyle_web/
├── app.py              ← Backend Flask (toda a lógica)
├── requirements.txt    ← Dependências Python
├── Procfile            ← Instrução de start para Render/Railway
├── README.md           ← Este arquivo
└── templates/
    ├── landing.html    ← Página inicial (login/cadastro)
    └── app.html        ← App principal (SPA mobile)
```

O banco `swapstyle.db` é criado automaticamente na primeira execução.

---

## Notas importantes

- No plano gratuito do Render, o banco SQLite é **reiniciado** a cada deploy.
  Para produção real, use **PostgreSQL** (o Render oferece gratuitamente).
- A `SECRET_KEY` deve ser uma string longa e aleatória em produção.
- Para enviar e-mails de verificação, adicione Flask-Mail + SendGrid.

---

Feito com ❤️ e Python + Flask 🌸
